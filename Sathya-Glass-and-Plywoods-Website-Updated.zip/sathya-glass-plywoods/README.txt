SATHYA GLASS & PLYWOODS WEBSITE

FILES
- index.html: Website content and layout
- style.css: Design and responsive styling
- script.js: Mobile navigation, product filters, and English/Kannada language switch

HOW TO VIEW
1. Extract the ZIP file to a folder.
2. Keep all three files in the same folder.
3. Double-click index.html to open it in a browser.

FEATURES
- Responsive layout for mobile and desktop
- Product filters for Glass, Plywood, and Laminates
- WhatsApp product enquiry links and click-to-call phone link
- Clickable address, Google Maps directions and embedded map
- English/Kannada language switch (button in the navigation)
- About section states the business has more than 20 years of experience, as supplied by the owner

NOTES
- Internet access is required for online fonts, demonstration images, and the embedded Google Map.
- Product photos are illustrative. Replace them with actual shop photos when available.
- The Google Maps search/review link opens a search for the business; it is not a verified direct review link. If the shop has a Google Business Profile, replace it with the exact review link.
- The contact form is not included; WhatsApp and phone contact are enabled.
